USE [RIL.AOP]
GO

/****** Object:  StoredProcedure [dbo].[usp_CalculatePlantRequirement]    Script Date: 1/9/2026 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =====================================================
-- Stored Procedure: usp_CalculatePlantRequirement
-- Description: Calculates Process Demand (Production × Norms)
-- 
-- Logic:
--   1. Get Process Plants mapped to CPP Plant
--   2. Check if Direct or Grade-based:
--      - DIRECT: product_name AND normParameter_FK_Id NOT NULL
--      - GRADE-BASED: Either is NULL → use ALL production materials
--   3. Get Production from AOP table
--   4. Get Raw Materials (NormType=2) for CPP Plant
--   5. Get Norms (AOPConsumptionNorms → fallback AOPConsumptionNormsGrade)
--   6. Calculate: Demand = SUM(Production × Norms)
-- =====================================================

CREATE OR ALTER PROCEDURE [dbo].[usp_CalculatePlantRequirement]
(
    @Vertical_FK_Id   UNIQUEIDENTIFIER,
    @Site_FK_Id       UNIQUEIDENTIFIER,
    @CPPPlant_Id      UNIQUEIDENTIFIER,   -- Consumption/CPP Plant
    @AOPYear          VARCHAR(100)
)
AS
BEGIN
    SET NOCOUNT ON;

    /* ===============================
       1. Get Process Plants mapped to CPP Plant
          Also determine if Direct or Grade-based
       =============================== */
    ;WITH ProcessPlantMapping AS
    (
        SELECT 
            pcm.ProcessPlant_FK_Id,
            pcm.Consumption_FK_Id,
            pcm.product_name,
            pcm.normParameter_FK_Id,
            -- Direct = both NOT NULL, Grade-based = either is NULL
            CASE 
                WHEN pcm.product_name IS NOT NULL AND pcm.normParameter_FK_Id IS NOT NULL 
                THEN 1 
                ELSE 0 
            END AS IsDirect
        FROM ProcessConsumptionPlantMapping pcm
        WHERE pcm.Consumption_FK_Id = @CPPPlant_Id
          AND pcm.Sites_FK_Id = @Site_FK_Id
          AND pcm.Verticale_FK_Id = @Vertical_FK_Id
    ),

    /* ===============================
       2. Get Production Materials
          - DIRECT: Use specific normParameter_FK_Id from mapping
          - GRADE-BASED: Get ALL from NormParameters (NormType=1)
       =============================== */
    ProductionMaterials AS
    (
        -- DIRECT: Specific production material from mapping
        SELECT 
            ppm.ProcessPlant_FK_Id,
            ppm.normParameter_FK_Id AS ProductionMaterial_FK_Id,
            1 AS IsDirect
        FROM ProcessPlantMapping ppm
        WHERE ppm.IsDirect = 1
          AND ppm.normParameter_FK_Id IS NOT NULL

        UNION ALL

        -- GRADE-BASED: All production materials for the process plant
        SELECT 
            ppm.ProcessPlant_FK_Id,
            np.Id AS ProductionMaterial_FK_Id,
            0 AS IsDirect
        FROM ProcessPlantMapping ppm
        INNER JOIN NormParameters np 
            ON np.Plant_FK_Id = ppm.ProcessPlant_FK_Id
           AND np.NormType_FK_Id = 1  -- Production materials
        WHERE ppm.IsDirect = 0
    ),

    /* ===============================
       3. Get Production Quantities from AOP
       =============================== */
    ProductionData AS
    (
        SELECT
            pm.ProcessPlant_FK_Id,
            pm.ProductionMaterial_FK_Id,
            pm.IsDirect,
            a.Jan, a.Feb, a.March, a.April, a.May, a.June,
            a.July, a.Aug, a.Sep, a.Oct, a.Nov, a.Dec
        FROM ProductionMaterials pm
        INNER JOIN AOP a
            ON a.Material_FK_Id = pm.ProductionMaterial_FK_Id
           AND a.Plant_FK_Id    = pm.ProcessPlant_FK_Id
           AND a.Site_FK_Id     = @Site_FK_Id
           AND a.Vertical_FK_Id = @Vertical_FK_Id
           AND a.AOPYear        = @AOPYear
    ),

    /* ===============================
       4. Get Raw Materials / Utilities (NormType = 2)
          These are the materials we need to calculate demand for
       =============================== */
    RawMaterials AS
    (
        SELECT
            np.Id AS RawMaterial_FK_Id,
            np.Material_FK_Id,
            np.Plant_FK_Id
        FROM NormParameters np
        WHERE np.Plant_FK_Id = @CPPPlant_Id
          AND np.NormType_FK_Id = 2  -- Raw materials / Utilities
    ),

    /* ===============================
       5. Resolve Norms
          Priority: AOPConsumptionNorms → AOPConsumptionNormsGrade
       =============================== */
    ResolvedNorms AS
    (
        SELECT
            rm.RawMaterial_FK_Id,
            pd.ProcessPlant_FK_Id,
            pd.ProductionMaterial_FK_Id,
            pd.IsDirect,

            -- Production values
            pd.Jan AS Prod_Jan, pd.Feb AS Prod_Feb, pd.March AS Prod_March,
            pd.April AS Prod_April, pd.May AS Prod_May, pd.June AS Prod_June,
            pd.July AS Prod_July, pd.Aug AS Prod_Aug, pd.Sep AS Prod_Sep,
            pd.Oct AS Prod_Oct, pd.Nov AS Prod_Nov, pd.Dec AS Prod_Dec,

            -- Norm source tracking
            cn.Id AS AOPConsumptionNorm_FK_Id,
            cg.Id AS AOPConsumptionNormGrade_FK_Id,
            CASE 
                WHEN cn.Id IS NOT NULL THEN 0
                WHEN cg.Id IS NOT NULL THEN 1
                ELSE NULL
            END AS IsGradeNormUsed,

            -- Norm values (prioritize direct norm, fallback to grade norm)
            COALESCE(cn.Jan, cg.Jan, 0) AS Norm_Jan,
            COALESCE(cn.Feb, cg.Feb, 0) AS Norm_Feb,
            COALESCE(cn.March, cg.March, 0) AS Norm_March,
            COALESCE(cn.April, cg.April, 0) AS Norm_April,
            COALESCE(cn.May, cg.May, 0) AS Norm_May,
            COALESCE(cn.June, cg.June, 0) AS Norm_June,
            COALESCE(cn.July, cg.July, 0) AS Norm_July,
            COALESCE(cn.Aug, cg.Aug, 0) AS Norm_Aug,
            COALESCE(cn.Sep, cg.Sep, 0) AS Norm_Sep,
            COALESCE(cn.Oct, cg.Oct, 0) AS Norm_Oct,
            COALESCE(cn.Nov, cg.Nov, 0) AS Norm_Nov,
            COALESCE(cn.Dec, cg.Dec, 0) AS Norm_Dec

        FROM RawMaterials rm
        CROSS JOIN ProductionData pd  -- Each raw material with each production

        -- Try to get direct consumption norm first
        LEFT JOIN AoPConsumtionNorm cn
            ON cn.Material_FK_Id = rm.RawMaterial_FK_Id
           AND cn.Plant_FK_Id    = @CPPPlant_Id
           AND cn.AOPYear        = @AOPYear

        -- Fallback to grade-based norm (only if direct norm not found)
        LEFT JOIN AOPConsumtionNormGrade cg
            ON cg.Material_FK_Id = rm.RawMaterial_FK_Id
           AND cg.Plant_FK_Id    = @CPPPlant_Id
           AND cg.AOPYear        = @AOPYear
           AND cn.Id IS NULL  -- Only use grade norm if direct norm doesn't exist
    )

    /* ===============================
       6. Final Calculation: Demand = SUM(Production × Norms)
          
          DIRECT: Single production × norm
          GRADE-BASED: SUM of all (grade production × grade norm)
       =============================== */
    SELECT
        @CPPPlant_Id AS CPPPlant_FK_Id,
        rn.RawMaterial_FK_Id,
        COALESCE(rn.AOPConsumptionNorm_FK_Id, rn.AOPConsumptionNormGrade_FK_Id) AS NormId,
        @AOPYear AS AOPYear,
        MAX(rn.IsGradeNormUsed) AS IsGradeNormUsed,
        MAX(rn.IsDirect) AS IsDirect,

        -- Demand = SUM(Production × Norm) for each month
        SUM(ISNULL(rn.Prod_April, 0) * ISNULL(rn.Norm_April, 0)) AS April,
        SUM(ISNULL(rn.Prod_May, 0) * ISNULL(rn.Norm_May, 0)) AS May,
        SUM(ISNULL(rn.Prod_June, 0) * ISNULL(rn.Norm_June, 0)) AS June,
        SUM(ISNULL(rn.Prod_July, 0) * ISNULL(rn.Norm_July, 0)) AS July,
        SUM(ISNULL(rn.Prod_Aug, 0) * ISNULL(rn.Norm_Aug, 0)) AS Aug,
        SUM(ISNULL(rn.Prod_Sep, 0) * ISNULL(rn.Norm_Sep, 0)) AS Sep,
        SUM(ISNULL(rn.Prod_Oct, 0) * ISNULL(rn.Norm_Oct, 0)) AS Oct,
        SUM(ISNULL(rn.Prod_Nov, 0) * ISNULL(rn.Norm_Nov, 0)) AS Nov,
        SUM(ISNULL(rn.Prod_Dec, 0) * ISNULL(rn.Norm_Dec, 0)) AS Dec,
        SUM(ISNULL(rn.Prod_Jan, 0) * ISNULL(rn.Norm_Jan, 0)) AS Jan,
        SUM(ISNULL(rn.Prod_Feb, 0) * ISNULL(rn.Norm_Feb, 0)) AS Feb,
        SUM(ISNULL(rn.Prod_March, 0) * ISNULL(rn.Norm_March, 0)) AS March

    FROM ResolvedNorms rn

    GROUP BY
        rn.RawMaterial_FK_Id,
        COALESCE(rn.AOPConsumptionNorm_FK_Id, rn.AOPConsumptionNormGrade_FK_Id)

    ORDER BY
        rn.RawMaterial_FK_Id;

END;
GO

-- =====================================================
-- TEST EXECUTION
-- =====================================================
-- EXEC [dbo].[usp_CalculatePlantRequirement] 
--     @Vertical_FK_Id = 'your-vertical-id',
--     @Site_FK_Id = 'your-site-id',
--     @CPPPlant_Id = 'your-cpp-plant-id',
--     @AOPYear = '2025-26';
-- GO
