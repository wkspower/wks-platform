-- =====================================================
-- Table: CalculatedProcessDemand
-- Database: SQL Server
-- Description: Stores Process Plant utility demand/budget data
-- Financial Year: April to March (Indian FY format)
-- =====================================================

-- Drop table if exists
IF OBJECT_ID('dbo.CalculatedProcessDemand', 'U') IS NOT NULL
    DROP TABLE dbo.CalculatedProcessDemand;
GO

-- Create the main table
CREATE TABLE dbo.CalculatedProcessDemand (
    id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(), -- Unique ID (GUID)
    financial_year VARCHAR(10) NOT NULL,            -- AOP Year: "2025-26", "2026-27"
    process_plant VARCHAR(100) NOT NULL,            -- e.g., "NMD - EG", "NMD - GAS CRACKER"
    process_plant_id VARCHAR(20) NOT NULL,          -- e.g., "40N3", "40N8"
    cpp_utility VARCHAR(100) NOT NULL,              -- e.g., "COMPRESSED AIR", "Cooling Water 2"
    cpp_utility_id VARCHAR(50) NOT NULL,            -- e.g., "310027904", "NITROGENG", "RAW WATER"
    cpp_plant VARCHAR(100),                         -- e.g., "NMD - Utility Plant"
    cpp_plant_id VARCHAR(20),                       -- e.g., "40NF", "40NG"
    uom VARCHAR(20) NOT NULL,                       -- Unit: "NM3", "KM3", "M3", "MT", "KWH"
    apr DECIMAL(18,3) DEFAULT 0,                   -- Month 1 of FY
    may DECIMAL(18,3) DEFAULT 0,                    -- Month 2 of FY
    jun DECIMAL(18,3) DEFAULT 0,                    -- Month 3 of FY
    jul DECIMAL(18,3) DEFAULT 0,                    -- Month 4 of FY
    aug DECIMAL(18,3) DEFAULT 0,                    -- Month 5 of FY
    sep DECIMAL(18,3) DEFAULT 0,                    -- Month 6 of FY
    oct DECIMAL(18,3) DEFAULT 0,                    -- Month 7 of FY
    nov DECIMAL(18,3) DEFAULT 0,                    -- Month 8 of FY
    dec DECIMAL(18,3) DEFAULT 0,                    -- Month 9 of FY
    jan DECIMAL(18,3) DEFAULT 0,                    -- Month 10 of FY
    feb DECIMAL(18,3) DEFAULT 0,                    -- Month 11 of FY
    mar DECIMAL(18,3) DEFAULT 0,                    -- Month 12 of FY
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

-- Create indexes for faster queries
CREATE INDEX idx_pp_budget_financial_year ON dbo.CalculatedProcessDemand(financial_year);
CREATE INDEX idx_pp_budget_process_plant ON dbo.CalculatedProcessDemand(process_plant);
CREATE INDEX idx_pp_budget_process_plant_id ON dbo.CalculatedProcessDemand(process_plant_id);
CREATE INDEX idx_pp_budget_cpp_utility ON dbo.CalculatedProcessDemand(cpp_utility);
GO

-- Add unique constraint to prevent duplicate entries
CREATE UNIQUE INDEX idx_pp_budget_unique_record ON dbo.CalculatedProcessDemand(
    financial_year, process_plant_id, cpp_utility_id, cpp_plant_id
) WHERE cpp_plant_id IS NOT NULL;
GO

-- =====================================================
-- INSERT DATA FOR FINANCIAL YEAR 2025-26
-- =====================================================

INSERT INTO dbo.CalculatedProcessDemand (
    id, financial_year, process_plant, process_plant_id, cpp_utility, cpp_utility_id, 
    cpp_plant, cpp_plant_id, uom,
    apr, may, jun, jul, aug, sep, oct, nov, dec, jan, feb, mar
) VALUES

-- =====================================================
-- NMD - EG (40N3)
-- =====================================================
(NEWID(), '2025-26', 'NMD - EG', '40N3', 'COMPRESSED AIR', '310027904', 'NMD - Utility Plant', '40NF', 'NM3',
 531520, 586720, 561720, 543600, 561720, 561720, 543600, 561720, 543936, 561720, 561720, 507360),

(NEWID(), '2025-26', 'NMD - EG', '40N3', 'Cooling Water 2', '310028004', 'NMD - Utility Plant', '40NF', 'KM3',
 3577, 3353, 3779, 3657, 3779, 3779, 3658, 3779, 1991, 3779, 3779, 3414),

(NEWID(), '2025-26', 'NMD - EG', '40N3', 'D M Water', '310027966', 'NMD - Utility Plant', '40NF', 'M3',
 1267, 1570, 1339, 1296, 1339, 1339, 1296, 1339, 6291, 1339, 1339, 1210),

(NEWID(), '2025-26', 'NMD - EG', '40N3', 'HP Steam_Dis', '310027939', 'NMD - Utility/Power Dist', '40NG', 'MT',
 350, 0, 2600, 4500, 1040, 2800, 0, 0, 0, 0, 0, 0),

(NEWID(), '2025-26', 'NMD - EG', '40N3', 'LP Steam_Dis', '310027965', 'NMD - Utility/Power Dist', '40NG', 'MT',
 3578, 3781, 3781, 3659, 3829, 3781, 3659, 3781, 2497, 3781, 3781, 3463),

(NEWID(), '2025-26', 'NMD - EG', '40N3', 'MP Steam_Dis', '310027940', 'NMD - Utility/Power Dist', '40NG', 'MT',
 11906, -34810, 12072, 11382, 11448, 13712, 14372, 11706, 11066, 16590, 17032, 15551),

(NEWID(), '2025-26', 'NMD - EG', '40N3', 'Nitrogen Gas', 'NITROGENG', 'NMD - Utility Plant', '40NF', 'NM3',
 295353, 216886, 312135, 302066, 312135, 312135, 302066, 312135, 235020, 312135, 312135, 281929),

(NEWID(), '2025-26', 'NMD - EG', '40N3', 'Oxygen', 'OXYGEN', 'NMD - Utility Plant', '40NF', 'MT',
 5787, 5547, 6187, 6023, 6260, 5856, 5464, 6162, 2641, 5548, 5503, 4960),

(NEWID(), '2025-26', 'NMD - EG', '40N3', 'Power_Dis', '310027910', 'NMD - Utility/Power Dist', '40NG', 'KWH',
 2061312, 22062216, 2178432, 2108160, 2178432, 2178432, 2108160, 2178432, 1344352, 2178432, 2178432, 1967616),

(NEWID(), '2025-26', 'NMD - EG', '40N3', 'Water', 'RAW WATER', 'NMD-Rev Proc', '40N0', 'M3',
 0, 0, 518, 0, 0, 0, 0, 0, 0, 0, 0, 0),

-- =====================================================
-- NMD - GAS CRACKER (40N8)
-- =====================================================
(NEWID(), '2025-26', 'NMD - GAS CRACKER', '40N8', 'COMPRESSED AIR', '310027904', 'NMD - Utility Plant', '40NF', 'NM3',
 2820357, 2916753, 2719860, 2800872, 2813261, 2831857, 2970128, 2616195, 2953980, 2849332, 2667144, 2928283),

(NEWID(), '2025-26', 'NMD - GAS CRACKER', '40N8', 'Cooling Water 1', '310028005', 'NMD - Utility Plant', '40NF', 'KM3',
 15194, 15714, 14653, 15089, 15156, 15256, 16001, 14095, 15914, 15351, 14369, 15776),

(NEWID(), '2025-26', 'NMD - GAS CRACKER', '40N8', 'D M Water', '310027966', 'NMD - Utility Plant', '40NF', 'M3',
 40410, 41791, 38970, 40131, 40308, 40574, 42556, 37485, 42324, 40825, 38215, 41956),

(NEWID(), '2025-26', 'NMD - GAS CRACKER', '40N8', 'HP Steam_Dis', '310027939', 'NMD - Utility/Power Dist', '40NG', 'MT',
 131, 135, 126, 130, 130, 131, 138, 121, 137, 132, 123, 136),

(NEWID(), '2025-26', 'NMD - GAS CRACKER', '40N8', 'LP Steam_Dis', '310027965', 'NMD - Utility/Power Dist', '40NG', 'MT',
 9490, 9815, 9152, 9425, 9466, 9529, 9994, 8803, 9940, 9588, 8975, 9853),

(NEWID(), '2025-26', 'NMD - GAS CRACKER', '40N8', 'MP Steam_Dis', '310027940', 'NMD - Utility/Power Dist', '40NG', 'MT',
 2124, 2197, 2049, 2110, 2119, 2133, 2237, 1971, 2225, 2146, 2009, 2206),

(NEWID(), '2025-26', 'NMD - GAS CRACKER', '40N8', 'Nitrogen Gas', 'NITROGENG', 'NMD - Utility Plant', '40NF', 'NM3',
 945561, 977879, 911868, 939028, 943182, 949417, 995774, 877113, 990360, 955276, 894195, 981745),

(NEWID(), '2025-26', 'NMD - GAS CRACKER', '40N8', 'Power_Dis', '310027910', 'NMD - Utility/Power Dist', '40NG', 'KWH',
 5562198, 5752306, 5364001, 5523769, 5548202, 5584877, 5857571, 5159558, 5825724, 5619341, 5260037, 5775045),

(NEWID(), '2025-26', 'NMD - GAS CRACKER', '40N8', 'SHP Steam_Dis', '310027924', 'NMD - Utility/Power Dist', '40NG', 'MT',
 20975, 21692, 20228, 20830, 20923, 21061, 22089, 19457, 21969, 21191, 19836, 21778),

(NEWID(), '2025-26', 'NMD - GAS CRACKER', '40N8', 'Water', 'RAW WATER', 'NMD-Rev Proc', '40N0', 'M3',
 16756, 17329, 16159, 16641, 16714, 16825, 17646, 15543, 17550, 16928, 15846, 17397),

-- =====================================================
-- NMD - Hexene1 (40NP)
-- =====================================================
(NEWID(), '2025-26', 'NMD - Hexene1', '40NP', 'COMPRESSED AIR', '310027904', 'NMD - Utility Plant', '40NF', 'NM3',
 194769, 174620, 181336, 201485, 174620, 194769, 188052, 167904, 201485, 201485, 154472, 201485),

(NEWID(), '2025-26', 'NMD - Hexene1', '40NP', 'Cooling Water 2', '310028004', 'NMD - Utility Plant', '40NF', 'KM3',
 735, 659, 684, 760, 659, 735, 710, 634, 760, 760, 583, 760),

(NEWID(), '2025-26', 'NMD - Hexene1', '40NP', 'D M Water', '310027966', 'NMD - Utility Plant', '40NF', 'M3',
 1044, 936, 972, 1080, 936, 1044, 1008, 900, 1080, 1080, 828, 1080),

(NEWID(), '2025-26', 'NMD - Hexene1', '40NP', 'HP Steam_Dis', '310027939', 'NMD - Utility/Power Dist', '40NG', 'MT',
 3452, 3095, 3214, 3571, 3095, 3452, 3333, 2976, 3571, 3571, 2738, 3571),

(NEWID(), '2025-26', 'NMD - Hexene1', '40NP', 'LP Steam_Dis', '310027965', 'NMD - Utility/Power Dist', '40NG', 'MT',
 3271, 2932, 3045, 3384, 2932, 3271, 3158, 2820, 3384, 3384, 2594, 3384),

(NEWID(), '2025-26', 'NMD - Hexene1', '40NP', 'Nitrogen Gas', 'NITROGENG', 'NMD - Utility Plant', '40NF', 'NM3',
 100399, 90013, 93475, 103861, 90013, 100399, 96937, 86551, 103861, 103861, 79627, 103861),

(NEWID(), '2025-26', 'NMD - Hexene1', '40NP', 'Power_Dis', '310027910', 'NMD - Utility/Power Dist', '40NG', 'KWH',
 334077, 299518, 311037, 345597, 299518, 334077, 322557, 287998, 345597, 345597, 264958, 345597),

(NEWID(), '2025-26', 'NMD - Hexene1', '40NP', 'Water', 'RAW WATER', 'NMD-Rev Proc', '40N0', 'M3',
 1393, 1249, 1297, 1441, 1249, 1393, 1345, 1201, 1441, 1441, 1105, 1441),

-- =====================================================
-- NMD - LDPE (40N5)
-- =====================================================
(NEWID(), '2025-26', 'NMD - LDPE', '40N5', 'COMPRESSED AIR', '310027904', 'NMD - Utility Plant', '40NF', 'NM3',
 419675, 433771, 419675, 431066, 364387, 427452, 445371, 427290, 445371, 445331, 352727, 441582),

(NEWID(), '2025-26', 'NMD - LDPE', '40N5', 'Cooling Water 2', '310028004', 'NMD - Utility Plant', '40NF', 'KM3',
 2535, 2620, 2535, 2626, 2197, 2583, 2690, 2603, 2690, 2690, 2126, 2690),

(NEWID(), '2025-26', 'NMD - LDPE', '40N5', 'D M Water', '310027966', 'NMD - Utility Plant', '40NF', 'M3',
 2743, 2835, 2743, 2818, 2382, 2794, 2911, 2793, 2911, 2911, 2306, 2887),

(NEWID(), '2025-26', 'NMD - LDPE', '40N5', 'HP Steam_Dis', '310027939', 'NMD - Utility/Power Dist', '40NG', 'MT',
 491, 508, 491, 449, 438, 499, 523, 445, 523, 522, 425, 460),

(NEWID(), '2025-26', 'NMD - LDPE', '40N5', 'LP Steam_Dis', '310027965', 'NMD - Utility/Power Dist', '40NG', 'MT',
 456, 471, 456, 468, 396, 464, 484, 464, 484, 484, 383, 479),

(NEWID(), '2025-26', 'NMD - LDPE', '40N5', 'Nitrogen Gas', 'NITROGENG', 'NMD - Utility Plant', '40NF', 'NM3',
 266284, 275228, 266284, 273511, 231203, 271218, 282588, 271115, 282588, 282562, 223805, 280184),

(NEWID(), '2025-26', 'NMD - LDPE', '40N5', 'Power_Dis', '310027910', 'NMD - Utility/Power Dist', '40NG', 'KWH',
 6057013, 6259115, 6057013, 6282461, 5245889, 6170373, 6425526, 6227424, 6425526, 6425635, 5075998, 6435728),

(NEWID(), '2025-26', 'NMD - LDPE', '40N5', 'Water', 'RAW WATER', 'NMD-Rev Proc', '40N0', 'M3',
 310, 320, 310, 318, 269, 316, 329, 316, 329, 329, 260, 326),

-- =====================================================
-- NMD - LLDE / HDPE (40N6)
-- =====================================================
(NEWID(), '2025-26', 'NMD - LLDE / HDPE', '40N6', 'COMPRESSED AIR', '310027904', 'NMD - Utility Plant', '40NF', 'NM3',
 1506748, 1589645, 1300648, 1324017, 1590402, 1539284, 1546424, 1539087, 1543723, 1141170, 1460206, 1600202),

(NEWID(), '2025-26', 'NMD - LLDE / HDPE', '40N6', 'Cooling Water 2', '310028004', 'NMD - Utility Plant', '40NF', 'KM3',
 993, 1076, 890, 996, 1377, 1329, 1023, 1040, 1046, 883, 1247, 1363),

(NEWID(), '2025-26', 'NMD - LLDE / HDPE', '40N6', 'D M Water', '310027966', 'NMD - Utility Plant', '40NF', 'M3',
 9823, 10830, 9090, 7817, 9060, 8777, 10104, 10464, 10527, 6842, 8416, 9220),

(NEWID(), '2025-26', 'NMD - LLDE / HDPE', '40N6', 'HP Steam_Dis', '310027939', 'NMD - Utility/Power Dist', '40NG', 'MT',
 548, 534, 382, 525, 534, 516, 556, 516, 501, 426, 483, 534),

(NEWID(), '2025-26', 'NMD - LLDE / HDPE', '40N6', 'LP Steam_Dis', '310027965', 'NMD - Utility/Power Dist', '40NG', 'MT',
 1035, 1114, 915, 948, 1209, 1169, 1061, 1077, 1079, 830, 1105, 1208),

(NEWID(), '2025-26', 'NMD - LLDE / HDPE', '40N6', 'Nitrogen Gas', 'NITROGENG', 'NMD - Utility Plant', '40NF', 'NM3',
 3491048, 3702792, 2990988, 3166797, 3879706, 3746314, 3571228, 3577401, 3558097, 2756956, 3532926, 3876923),

(NEWID(), '2025-26', 'NMD - LLDE / HDPE', '40N6', 'Power_Dis', '310027910', 'NMD - Utility/Power Dist', '40NG', 'KWH',
 10800723, 11498439, 9395167, 9910167, 12641133, 12218559, 11078843, 11126718, 11146209, 8607365, 11508040, 12594313),

(NEWID(), '2025-26', 'NMD - LLDE / HDPE', '40N6', 'Water', 'RAW WATER', 'NMD-Rev Proc', '40N0', 'M3',
 4624, 5046, 4216, 3783, 4616, 4479, 4745, 4887, 4920, 3285, 4272, 4657),

-- =====================================================
-- NMD - PET RECYCLING (40N1)
-- =====================================================
(NEWID(), '2025-26', 'NMD - PET RECYCLING', '40N1', 'COMPRESSED AIR', '310027904', 'NMD - Utility Plant', '40NF', 'NM3',
 48942, 61850, 58623, 36034, 60774, 59699, 51093, 59699, 60774, 51631, 54320, 61850),

(NEWID(), '2025-26', 'NMD - PET RECYCLING', '40N1', 'Cooling Water 2', '310028004', 'NMD - Utility Plant', '40NF', 'KM3',
 11, 14, 13, 8, 14, 13, 11, 13, 14, 12, 12, 14),

(NEWID(), '2025-26', 'NMD - PET RECYCLING', '40N1', 'Nitrogen Gas', 'NITROGENG', 'NMD - Utility Plant', '40NF', 'NM3',
 127, 160, 152, 93, 157, 155, 132, 155, 157, 134, 141, 160),

(NEWID(), '2025-26', 'NMD - PET RECYCLING', '40N1', 'Power_Dis', '310027910', 'NMD - Utility/Power Dist', '40NG', 'KWH',
 169260, 213900, 202740, 124620, 210180, 206460, 176700, 206460, 210180, 178560, 187860, 213900),

(NEWID(), '2025-26', 'NMD - PET RECYCLING', '40N1', 'Water', 'RAW WATER', 'NMD-Rev Proc', '40N0', 'M3',
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),

-- =====================================================
-- NMD - PP (40N7)
-- =====================================================
(NEWID(), '2025-26', 'NMD - PP', '40N7', 'COMPRESSED AIR', '310027904', 'NMD - Utility Plant', '40NF', 'NM3',
 529135, 550314, 417825, 550314, 547055, 532607, 550524, 532588, 554586, 560517, 498381, 552345),

(NEWID(), '2025-26', 'NMD - PP', '40N7', 'Cooling Water 2', '310028004', 'NMD - Utility Plant', '40NF', 'KM3',
 1157, 1203, 907, 1203, 1196, 1164, 1204, 1164, 1194, 1226, 1089, 1207),

(NEWID(), '2025-26', 'NMD - PP', '40N7', 'D M Water', '310027966', 'NMD - Utility Plant', '40NF', 'M3',
 134, 140, 106, 140, 139, 135, 140, 135, 139, 142, 127, 140),

(NEWID(), '2025-26', 'NMD - PP', '40N7', 'LP Steam_Dis', '310027965', 'NMD - Utility/Power Dist', '40NG', 'MT',
 2281, 2372, 1797, 2372, 2358, 2296, 2373, 2295, 2379, 2416, 2148, 2380),

(NEWID(), '2025-26', 'NMD - PP', '40N7', 'Nitrogen Gas', 'NITROGENG', 'NMD - Utility Plant', '40NF', 'NM3',
 338858, 352420, 271123, 352420, 350334, 341081, 352555, 341069, 365805, 358950, 319159, 353717),

(NEWID(), '2025-26', 'NMD - PP', '40N7', 'Power_Dis', '310027910', 'NMD - Utility/Power Dist', '40NG', 'KWH',
 2652342, 2758504, 2088987, 2758504, 2742158, 2669735, 2759556, 2669646, 2763388, 2809563, 2498414, 2768946),

(NEWID(), '2025-26', 'NMD - PP', '40N7', 'Water', 'RAW WATER', 'NMD-Rev Proc', '40N0', 'M3',
 48, 50, 128, 50, 49, 48, 50, 48, 322, 51, 45, 50);

GO

-- =====================================================
-- VERIFICATION QUERY
-- =====================================================
-- Run this to verify data looks like your Excel
SELECT 
    process_plant AS [Process Plant],
    process_plant_id AS [Process Plant ID],
    cpp_utility AS [CPP Utilities],
    cpp_utility_id AS [CPP Utility IDs],
    cpp_plant AS [CPP Plant],
    cpp_plant_id AS [CPP Plant ID],
    uom AS [UOM],
    apr AS [Apr],
    may AS [May],
    jun AS [Jun],
    jul AS [Jul],
    aug AS [Aug],
    sep AS [Sep],
    oct AS [Oct],
    nov AS [Nov],
    dec AS [Dec],
    jan AS [Jan],
    feb AS [Feb],
    mar AS [Mar]
FROM dbo.CalculatedProcessDemand
WHERE financial_year = '2025-26'
ORDER BY process_plant, cpp_utility;
GO
