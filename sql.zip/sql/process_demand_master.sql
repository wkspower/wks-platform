-- =====================================================
-- Table: ProcessDemandMaster
-- Description: Master data for Process Plant utility mapping
-- Source: Extracted from CalculatedProcessDemand (2025-26)
-- =====================================================

-- Drop table if exists
IF OBJECT_ID('dbo.ProcessDemandMaster', 'U') IS NOT NULL
    DROP TABLE dbo.ProcessDemandMaster;
GO

-- Create the master table
CREATE TABLE dbo.ProcessDemandMaster (
    id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    process_plant VARCHAR(100) NOT NULL,
    process_plant_id VARCHAR(20) NOT NULL,
    cpp_utility VARCHAR(100) NOT NULL,
    cpp_utility_id VARCHAR(50) NOT NULL,
    cpp_plant VARCHAR(100),
    cpp_plant_id VARCHAR(20),
    uom VARCHAR(20) NOT NULL,
    display_order INT DEFAULT 0,
    is_active BIT DEFAULT 1,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

-- Create unique index to prevent duplicates
CREATE UNIQUE INDEX idx_process_demand_master_unique ON dbo.ProcessDemandMaster(
    process_plant_id, cpp_utility_id, cpp_plant_id
) WHERE cpp_plant_id IS NOT NULL;
GO

-- Create index for faster queries
CREATE INDEX idx_process_demand_master_plant ON dbo.ProcessDemandMaster(process_plant_id);
CREATE INDEX idx_process_demand_master_active ON dbo.ProcessDemandMaster(is_active);
GO

-- =====================================================
-- INSERT MASTER DATA FROM CalculatedProcessDemand
-- Extract unique combinations from existing 2025-26 data
-- =====================================================

INSERT INTO dbo.ProcessDemandMaster (
    process_plant, process_plant_id, cpp_utility, cpp_utility_id, 
    cpp_plant, cpp_plant_id, uom, display_order
)
SELECT DISTINCT
    process_plant,
    process_plant_id,
    cpp_utility,
    cpp_utility_id,
    cpp_plant,
    cpp_plant_id,
    uom,
    ROW_NUMBER() OVER (ORDER BY process_plant, cpp_utility) AS display_order
FROM dbo.CalculatedProcessDemand
WHERE financial_year = '2025-26';
GO

-- =====================================================
-- VERIFICATION QUERY
-- =====================================================
SELECT 
    process_plant AS [Process Plant],
    process_plant_id AS [Process Plant ID],
    cpp_utility AS [CPP Utility],
    cpp_utility_id AS [CPP Utility ID],
    cpp_plant AS [CPP Plant],
    cpp_plant_id AS [CPP Plant ID],
    uom AS [UOM],
    display_order AS [Order]
FROM dbo.ProcessDemandMaster
WHERE is_active = 1
ORDER BY display_order;
GO

-- Count records
SELECT COUNT(*) AS TotalMasterRecords FROM dbo.ProcessDemandMaster;
GO
